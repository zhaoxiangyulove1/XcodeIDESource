import KAEMMService

public protocol LarkKAContainer {
  func ka_register<Service>(_ serviceType: Service.Type, factory: @escaping (LarkKAContainer) -> Service)
  func ka_resolve<Service>(_ serviceType: Service.Type) -> Service?
}

public class LarkKARemoteBuildAssembly: NSObject {
  public override init() {
    
  }
  
  public func ka_assemble() {
    
  }
  
  public func ka_registContainer(container: LarkKAContainer) {
//    container.ka_register(KAEMMServiceProtocol.self) { r in
//      let temp = KAEMMServiceIMP()
//      temp.dependency = r.ka_resolve(KAEMMDependencyProtocol.self)
//      return temp
//    }
  }
}

public class LarkKARemoteTask {
  public func ka_execute() {
    
  }
}
